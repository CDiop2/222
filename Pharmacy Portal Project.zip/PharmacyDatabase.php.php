<?php
class PharmacyDatabase {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "pharmacy_portal_db";
    private $conn;

    public function __construct() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // User management
    public function addUser($userName, $contactInfo, $userType, $password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("CALL AddOrUpdateUser(NULL, ?, ?, ?, ?)");
        $stmt->bind_param("ssss", $userName, $contactInfo, $userType, $hashedPassword);
        return $stmt->execute();
    }

    public function getUserDetails($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM Users WHERE userId = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function verifyUser($userName, $password) {
        $stmt = $this->conn->prepare("SELECT userId, passwordHash, userType FROM Users WHERE userName = ?");
        $stmt->bind_param("s", $userName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['passwordHash'])) {
                return $user;
            }
        }
        return false;
    }

    // Medication management
    public function addMedication($medicationName, $dosage, $manufacturer, $initialQuantity) {
        $this->conn->begin_transaction();
        
        try {
            // Add medication
            $stmt = $this->conn->prepare("INSERT INTO Medications (medicationName, dosage, manufacturer) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $medicationName, $dosage, $manufacturer);
            $stmt->execute();
            $medicationId = $this->conn->insert_id;
            
            // Add to inventory
            $stmt = $this->conn->prepare("INSERT INTO Inventory (medicationId, quantityAvailable, lastUpdated) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $medicationId, $initialQuantity);
            $stmt->execute();
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    public function getMedicationInventory() {
        $result = $this->conn->query("SELECT * FROM MedicationInventoryView");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Prescription management
    public function addPrescription($userId, $medicationId, $dosageInstructions, $quantity) {
        $stmt = $this->conn->prepare("INSERT INTO Prescriptions (userId, medicationId, prescribedDate, dosageInstructions, quantity) VALUES (?, ?, NOW(), ?, ?)");
        $stmt->bind_param("iisi", $userId, $medicationId, $dosageInstructions, $quantity);
        return $stmt->execute();
    }

    public function getPrescriptionsForUser($userId) {
        $stmt = $this->conn->prepare("
            SELECT p.*, m.medicationName, m.dosage 
            FROM Prescriptions p
            JOIN Medications m ON p.medicationId = m.medicationId
            WHERE p.userId = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Sales management
    public function processSale($prescriptionId, $quantitySold, $saleAmount) {
        $stmt = $this->conn->prepare("CALL ProcessSale(?, ?, ?)");
        $stmt->bind_param("iid", $prescriptionId, $quantitySold, $saleAmount);
        return $stmt->execute();
    }

    public function close() {
        $this->conn->close();
    }
}
?>