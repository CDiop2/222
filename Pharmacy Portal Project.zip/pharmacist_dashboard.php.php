<?php
session_start();
require_once 'PharmacyDatabase.php';

// Check if user is logged in and is a pharmacist
if (!isset($_SESSION['userId']) || $_SESSION['userType'] !== 'pharmacist') {
    header("Location: login.php");
    exit();
}

$db = new PharmacyDatabase();
$inventory = $db->getMedicationInventory();
$db->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pharmacist Dashboard</title>
</head>
<body>
    <h1>Welcome, Pharmacist</h1>
    <a href="logout.php">Logout</a>
    
    <h2>Medication Inventory</h2>
    <table border="1">
        <tr>
            <th>Medication Name</th>
            <th>Dosage</th>
            <th>Manufacturer</th>
            <th>Quantity Available</th>
        </tr>
        <?php foreach ($inventory as $item): ?>
        <tr>
            <td><?php echo htmlspecialchars($item['medicationName']); ?></td>
            <td><?php echo htmlspecialchars($item['dosage']); ?></td>
            <td><?php echo htmlspecialchars($item['manufacturer']); ?></td>
            <td><?php echo htmlspecialchars($item['quantityAvailable']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h2>Add New Medication</h2>
    <form action="add_medication.php" method="POST">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        <label>Dosage:</label>
        <input type="text" name="dosage" required><br>
        <label>Manufacturer:</label>
        <input type="text" name="manufacturer"><br>
        <label>Initial Quantity:</label>
        <input type="number" name="quantity" required><br>
        <button type="submit">Add Medication</button>
    </form>
</body>
</html>