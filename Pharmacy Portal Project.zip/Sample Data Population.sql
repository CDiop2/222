-- Users
INSERT INTO Users (userName, contactInfo, userType, passwordHash) VALUES 
('pharm1', 'pharm1@example.com', 'pharmacist', '$2y$10$N9qo8uLOickgx2ZMRZoMy.MrYI9o8X3B7y7eI6UjJQ7J1ZJQl7v6O'), -- password: pharm123
('pharm2', 'pharm2@example.com', 'pharmacist', '$2y$10$N9qo8uLOickgx2ZMRZoMy.MrYI9o8X3B7y7eI6UjJQ7J1ZJQl7v6O'), -- password: pharm123
('patient1', 'patient1@example.com', 'patient', '$2y$10$8uLOickgx2ZMRZoMy.MrYI9o8X3B7y7eI6UjJQ7J1ZJQl7v6ON9qo'), -- password: patient123
('patient2', 'patient2@example.com', 'patient', '$2y$10$8uLOickgx2ZMRZoMy.MrYI9o8X3B7y7eI6UjJQ7J1ZJQl7v6ON9qo'); -- password: patient123

-- Medications
INSERT INTO Medications (medicationName, dosage, manufacturer) VALUES 
('Ibuprofen', '200mg', 'Advil'),
('Amoxicillin', '500mg', 'GlaxoSmithKline'),
('Lisinopril', '10mg', 'AstraZeneca');

-- Inventory
INSERT INTO Inventory (medicationId, quantityAvailable, lastUpdated) VALUES
(1, 100, NOW()),
(2, 50, NOW()),
(3, 75, NOW());

-- Prescriptions
INSERT INTO Prescriptions (userId, medicationId, prescribedDate, dosageInstructions, quantity) VALUES
(3, 1, NOW(), 'Take 1 tablet every 6 hours as needed for pain', 30),
(3, 2, NOW(), 'Take 1 tablet every 8 hours for 10 days', 30),
(4, 3, NOW(), 'Take 1 tablet daily', 90);

-- Sales
CALL ProcessSale(1, 30, 15.99);
CALL ProcessSale(2, 30, 25.50);
CALL ProcessSale(3, 90, 45.00);