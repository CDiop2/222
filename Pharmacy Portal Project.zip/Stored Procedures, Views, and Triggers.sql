-- AddOrUpdateUser Stored Procedure
DELIMITER //
CREATE PROCEDURE AddOrUpdateUser(
    IN p_userId INT,
    IN p_userName VARCHAR(45),
    IN p_contactInfo VARCHAR(200),
    IN p_userType ENUM('pharmacist','patient'),
    IN p_password VARCHAR(255)
)
BEGIN
    IF p_userId IS NULL THEN
        INSERT INTO Users (userName, contactInfo, userType, passwordHash)
        VALUES (p_userName, p_contactInfo, p_userType, p_password);
    ELSE
        UPDATE Users 
        SET userName = p_userName, 
            contactInfo = p_contactInfo, 
            userType = p_userType,
            passwordHash = IFNULL(p_password, passwordHash)
        WHERE userId = p_userId;
    END IF;
END //
DELIMITER ;

-- ProcessSale Stored Procedure
DELIMITER //
CREATE PROCEDURE ProcessSale(
    IN p_prescriptionId INT,
    IN p_quantitySold INT,
    IN p_saleAmount DECIMAL(10,2)
)
BEGIN
    DECLARE v_medicationId INT;
    DECLARE v_availableQuantity INT;
    
    -- Get medication ID from prescription
    SELECT medicationId INTO v_medicationId
    FROM Prescriptions
    WHERE prescriptionId = p_prescriptionId;
    
    -- Check available quantity
    SELECT quantityAvailable INTO v_availableQuantity
    FROM Inventory
    WHERE medicationId = v_medicationId;
    
    IF v_availableQuantity >= p_quantitySold THEN
        -- Record the sale
        INSERT INTO Sales (prescriptionId, saleDate, quantitySold, saleAmount)
        VALUES (p_prescriptionId, NOW(), p_quantitySold, p_saleAmount);
        
        -- Update inventory
        UPDATE Inventory
        SET quantityAvailable = quantityAvailable - p_quantitySold,
            lastUpdated = NOW()
        WHERE medicationId = v_medicationId;
        
        SELECT 'Sale processed successfully' AS message;
    ELSE
        SELECT 'Insufficient inventory' AS message;
    END IF;
END //
DELIMITER ;

-- MedicationInventoryView
CREATE VIEW MedicationInventoryView AS
SELECT 
    m.medicationId,
    m.medicationName,
    m.dosage,
    m.manufacturer,
    i.quantityAvailable
FROM 
    Medications m
JOIN 
    Inventory i ON m.medicationId = i.medicationId;

-- AfterPrescriptionInsert Trigger
DELIMITER //
CREATE TRIGGER AfterPrescriptionInsert
AFTER INSERT ON Prescriptions
FOR EACH ROW
BEGIN
    -- Update inventory
    UPDATE Inventory
    SET quantityAvailable = quantityAvailable - NEW.quantity,
        lastUpdated = NOW()
    WHERE medicationId = NEW.medicationId;
    
    -- Check if inventory is low (less than 10)
    IF (SELECT quantityAvailable FROM Inventory WHERE medicationId = NEW.medicationId) < 10 THEN
        INSERT INTO Notifications (message, createdAt)
        VALUES (CONCAT('Low inventory for medication ID: ', NEW.medicationId), NOW());
    END IF;
END //
DELIMITER ;