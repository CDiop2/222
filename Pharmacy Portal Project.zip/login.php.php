<?php
session_start();
require_once 'PharmacyDatabase.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $db = new PharmacyDatabase();
    $user = $db->verifyUser($username, $password);
    $db->close();
    
    if ($user) {
        $_SESSION['userId'] = $user['userId'];
        $_SESSION['userType'] = $user['userType'];
        
        if ($user['userType'] === 'pharmacist') {
            header("Location: pharmacist_dashboard.php");
        } else {
            header("Location: patient_dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pharmacy Portal - Login</title>
</head>
<body>
    <h1>Pharmacy Portal Login</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" required><br>
        <label>Password:</label>
        <input type="password" name="password" required><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>